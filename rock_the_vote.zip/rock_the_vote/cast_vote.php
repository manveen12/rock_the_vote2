<?php
// reading data which is sent from app in jsonobject form
$data = file_get_contents('php://input');
// decoding the json object
$decoded_data = json_decode($data , true);

//{"answer":"","poll_id":"11","email":"charan@gmail.com","user_type":"admin"}


$poll_id = $decoded_data['poll_id']; // give keys which are given in app while creating json object
$user_id = $decoded_data['email'];// give keys which are given in app while creating json object
$answer=$decoded_data['answer'];

$type=$decoded_data['user_type'];
// creating connection with database and saving in variable  
$connection = mysqli_connect('localhost' , 'root' , '');
// selecting database user 
mysqli_select_db($connection , 'rock_the_vote');
// query to check whether same email and password exist or not

if($type=="user"){
	
	$user_id = $decoded_data['user_id'];
$result = mysqli_query($connection , "insert into user_result (poll_id,user_id,answer) values ('$poll_id','$user_id','$answer') ");

// if now row found mean no such data sent by user found in database
if($result)
	
	{
		// making key value pair with key named 'key' and value "not done"
		$response['key'] = "done";
		// converting key value pair into jsonobject form
		echo json_encode($response);
	}
	
	// if some row found mean data found in database
	else {
		
		
		$response['key'] = "not done";
		
		echo json_encode($response);
	}
}

if($type=="admin"){
	
	$admin_id = $decoded_data['admin_id'];
	
	$result = mysqli_query($connection ,  "insert into admin_result (poll_id,user_id ,answer) values ('$poll_id','$admin_id','$answer') ");


if($result)
	
	{
		// making key value pair with key named 'key' and value "not done"
		$response['key'] = "done";
		// converting key value pair into jsonobject form
		echo json_encode($response);
	}
	
	// if some row found mean data found in database
	else {
			
		$response['key'] = "not done";
		
		echo json_encode($response);
		
	}
}
?>