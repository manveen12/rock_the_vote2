<?php

$connection = mysqli_connect('localhost','root','');
mysqli_select_db($connection,'rock_the_vote');
$data = file_get_contents('php://input');
$decoded_data = json_decode($data,true);
$poll_id= $decoded_data['poll_id'];
$sql=mysqli_query($connection , "select * from comments  where Pid = '$poll_id'");

  
  while($row=mysqli_fetch_assoc($sql))
  $output[]=$row;


$response['result'] = $output;
 echo (json_encode($response));
  mysqli_close($connection);
?>