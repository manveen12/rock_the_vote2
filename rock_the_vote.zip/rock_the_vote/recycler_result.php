<?php

$connection = mysqli_connect('localhost','root','');
mysqli_select_db($connection,'rock_the_vote');
$data = file_get_contents('php://input');
$decoded_data = json_decode($data,true);
$Adid= $decoded_data['admin_key'];
$sql=mysqli_query($connection , "select * from viewresults ");

  
  while($row=mysqli_fetch_assoc($sql))
  $output[]=$row;


 
 
 echo (json_encode($output));
  mysqli_close($connection);
?>