<?php
$data = file_get_contents('php://input');
// decoding the json object
$decoded_data = json_decode($data , true);
$email = $decoded_data['email_key']; // give keys which are given in app while creating json object
$type = $decoded_data['type_key'];
$name=$decoded_data['name_key'];
$age=$decoded_data['age_key'];
$occupation=$decoded_data['occu_key'];


$connection = mysqli_connect('localhost' , 'root' , '');
mysqli_select_db($connection , 'rock_the_vote');

if($type== "user")
{

 $result  = mysqli_query($connection , "update userdetails set username ='$name', age ='$age',occupation='$occupation' where email = '$email'");
 
 while($r = mysqli_fetch_assoc($result))
 $row[] = $r;
$response['result']= $row;
 
 echo json_encode($response);
}


if($type== "admin")
{
 $result  = mysqli_query($connection ,"update admindetails set username = '$name', age ='$age',occupation='$occupation' where email ='$email'");
 
 while($r = mysqli_fetch_assoc($result))
 $row[] = $r;
$response['result']= $row;
 
 echo json_encode($response);
}  

?>  