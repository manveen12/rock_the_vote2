<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$poll_detail = $decoded_data['poll_question_key'];

$poll_date = $decoded_data['poll_date_key'];

$poll_from = $decoded_data['poll_timefrom_key'];
$poll_to = $decoded_data['poll_timeto_key'];
$o1=$decoded_data['option1'];
$o2=$decoded_data['option2'];
$o3=$decoded_data['option3'];
$o4=$decoded_data['option4'];
$type=$decoded_data['type'];
$aid=$decoded_data['aid'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'rock_the_vote');

mysqli_query($connection , "insert into polldetails (Aid ,poll_question , date , time_from ,time_to,poll_o1,poll_o2,poll_o3,poll_o4,poll_type) values ('$aid','$poll_detail' , '$poll_date' , '$poll_from','$poll_to','$o1','$o2','$o3','$o4','$type')");

$response['key'] = "1";
	
	echo json_encode($response);

	
	


?>  