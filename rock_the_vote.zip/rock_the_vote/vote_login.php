<?php
// reading data which is sent from app in jsonobject form

date_default_timezone_set('Asia/Kolkata');

$date = date('Y-m-d G:i', time());

$today = strtotime($date);



$data = file_get_contents('php://input');
// decoding the json object
$decoded_data = json_decode($data , true);
$email = $decoded_data['email_key']; // give keys which are given in app while creating json object
$password = $decoded_data['password'];// give keys which are given in app while creating json object
$poll_no=$decoded_data['poll_key'];


$type=$decoded_data['type'];
// creating connection with database and saving in variable  
$connection = mysqli_connect('localhost' , 'root' , '');
// selecting database user 
mysqli_select_db($connection , 'rock_the_vote');
// query to check whether same email and password exist or not

if($type=="user"){
$result = mysqli_query($connection , "select * from userdetails where email = '$email' and password = '$password' ");
// fetching number of rows returned in query 
$rows = mysqli_num_rows($result);
// if now row found mean no such data sent by user found in database
if($rows == 0)
	
	{
		// making key value pair with key named 'key' and value "not done"
		$response['key'] = "invalid data";
		// converting key value pair into jsonobject form
		echo json_encode($response);
	}
	
	// if some row found mean data found in database
	else {
		$r = mysqli_fetch_array($result);
	       $user_id = $r['Uid'];
		
		$result = mysqli_query($connection , "select * from polldetails where Pid = '$poll_no'");

		// making key value pair with key named 'key' and value "not done"
		$response['poll_details'] = mysqli_fetch_assoc($result);
		
		$poll_date = $response['poll_details']['date'];
		$poll_time = $response['poll_details']['time_from'];
		$poll_end = $response['poll_details']['time_to'];
		
		$end_time = $poll_date." ".$poll_end;
		
		$start_time = $poll_date." ".$poll_time;
		
		
		$fstart_time = strtotime($start_time);
		
		$fend_time = strtotime($end_time);
		if($fstart_time < $today)
		{
			if($fend_time < $today)
		{
			$response['key'] = "expires";
			// converting key value pair into jsonobject form
		   echo json_encode($response);
		
		
		
		}		
		$result2 = mysqli_query($connection , "select * from user_result where poll_id = '$poll_no' and user_id = '$user_id'");
			if(mysqli_num_rows($result2) > 0)
			{
				$response['key'] = "casted";
		
		// converting key value pair into jsonobject form
		echo json_encode($response);
			}
		
		
		else {
		$response['key'] = "done";
		
		// converting key value pair into jsonobject form
		echo json_encode($response);
		}
		}
		else {
			$response['key'] = "not started";
		
		// converting key value pair into jsonobject form
		echo json_encode($response);
		}
			
	}
}

if($type=="admin"){
	$result = mysqli_query($connection , "select * from admindetails where email = '$email' and password = '$password' ");
// fetching number of rows returned in query 
$rows = mysqli_num_rows($result);
// if now row found mean no such data sent by user found in database
if($rows == 0)
	
	{
		// making key value pair with key named 'key' and value "not done"
		$response['key'] = "invalid data";
		// converting key value pair into jsonobject form
		echo json_encode($response);
	}
	
	// if some row found mean data found in database
	else { $r = mysqli_fetch_array($result);
	       $admin_id = $r['Aid'];
			$result = mysqli_query($connection , "select * from polldetails where Pid = '$poll_no'");
		// making key value pair with key named 'key' and value "not done"
		$response['poll_details'] = mysqli_fetch_assoc($result);
		
		$poll_date = $response['poll_details']['date'];
		$poll_time = $response['poll_details']['time_from'];
		$poll_end = $response['poll_details']['time_to'];
		
		$end_time = $poll_date." ".$poll_end;
		
		$start_time = $poll_date." ".$poll_time;
		
		
		$fstart_time = strtotime($start_time);
		
		$fend_time = strtotime($end_time);
		if($fstart_time < $today)
		{
			if($fend_time < $today)
		{
			$response['key'] = "expires";
			// converting key value pair into jsonobject form
		   echo json_encode($response);
		
		
		
		}
		else {
			$result2 = mysqli_query($connection , "select * from admin_result where poll_id = '$poll_no' and user_id = '$admin_id'");
			if(mysqli_num_rows($result2) > 0)
			{
				$response['key'] = "casted";
		
		// converting key value pair into jsonobject form
		echo json_encode($response);
			}else {
		$response['key'] = "done";
		
		// converting key value pair into jsonobject form
		echo json_encode($response);
		}
		}
		}
		
		else {
			$response['key'] = "not started";
		
		// converting key value pair into jsonobject form
		echo json_encode($response);
		}
		
	}
}
?>