<?php

date_default_timezone_set('Asia/Kolkata');

date_default_timezone_set('Asia/Kolkata');

$date = date('Y-m-d G:i', time());

$today = strtotime($date);

$connection = mysqli_connect('localhost','root','');
mysqli_select_db($connection,'rock_the_vote');
$data = file_get_contents('php://input');
$decoded_data = json_decode($data,true);


$sql=mysqli_query($connection,"select * from polldetails");
  
  while($row=mysqli_fetch_assoc($sql))
  {
	  $pollon = $row['date'];
	  $polltime = $row['time_to'];
	  $polldate = strtotime($pollon." ".$polltime);
	  if( $polldate >= $today)
	  {
            $output[]=$row;
	  }
  }


 
 
 echo (json_encode($output));
  mysqli_close($connection);
  
?>