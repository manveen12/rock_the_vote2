<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$poll_id = $decoded_data['poll_id'];

$user_email = $decoded_data['user_email'];

$comment = $decoded_data['comment_key'];


$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'rock_the_vote');

$result = mysqli_query($connection , "insert into comments (Pid , email_id , comment) values ('$poll_id' , '$user_email' , '$comment')");

if($result) 
{
	$response['key'] = "done";
	
	echo json_encode($response);
	
}

	
	


?>  