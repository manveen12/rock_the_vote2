<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);  
$poll_name=$decoded_data['poll_name_key'];
$poll_detail = $decoded_data['poll_detail_key'];
$poll_date = $decoded_data['poll_date_key'];

$poll_from = $decoded_data['poll_from_key'];
$poll_to = $decoded_data['poll_to_key'];
$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'rock_the_vote');

mysqli_query($connection , "insert into opinion_poll (poll_name ,poll_question , date , time_from ,time_to) values ('$poll_name','$poll_detail' , '$poll_date' , '$poll_from','$poll_to')");

$response['key'] = "1";
	
	echo json_encode($response);

	
	


?>