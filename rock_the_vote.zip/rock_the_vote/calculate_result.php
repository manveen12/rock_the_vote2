<?php

date_default_timezone_set('Asia/Kolkata');

date_default_timezone_set('Asia/Kolkata');

$date = date('Y-m-d G:i', time());

$today = strtotime($date);

$connection = mysqli_connect('localhost','root','');
mysqli_select_db($connection,'rock_the_vote');
$data = file_get_contents('php://input');
$decoded_data = json_decode($data,true);

$Adid= $decoded_data['admin_key'];

$sql=mysqli_query($connection,"select * from polldetails where Aid = '$Adid' ");

if(mysqli_num_rows($sql) > 0){
  
   $output = array();
  while($row=mysqli_fetch_assoc($sql))
  {
	  $pollon = $row['date'];
	  $polltime = $row['time_to'];
	  $polldate = strtotime($pollon." ".$polltime);
	  if( $polldate < $today)
	  {
            array_push($output , $row);
	  }
  }
 $response['result'] = $output;
 echo (json_encode($response));
}

	
  mysqli_close($connection);
  
?>